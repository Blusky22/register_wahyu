document.getElementById("registerForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const nomor = document.getElementById("nomorHp").value;
  const tanggal = document.getElementById("tanggal").value;

  const table = document.getElementById("dataTable").getElementsByTagName("tbody")[0];
  const newRow = table.insertRow();

  newRow.insertCell(0).textContent = name;
  newRow.insertCell(1).textContent = email;
  newRow.insertCell(2).textContent = nomor;
  newRow.insertCell(3).textContent = tanggal;

  document.getElementById("registerForm").reset();
});
