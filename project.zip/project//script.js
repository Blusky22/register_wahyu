document.getElementById("registerForm").addEventListener("submit", function (e) {
  e.preventDefault();

  // Ambil nilai input
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const nomor = document.getElementById("nomorHp").value.trim();
  const tanggal = document.getElementById("tanggal").value;

  // Simpan ke localStorage
  const user = {
    nama: name,
    email: email,
    password: password,
    nomorHp: nomor,
    tanggalLahir: tanggal
  };

  localStorage.setItem(email, JSON.stringify(user));

  // Tampilkan ke tabel
  const table = document.getElementById("dataTable").getElementsByTagName("tbody")[0];
  const newRow = table.insertRow();

  newRow.insertCell(0).textContent = name;
  newRow.insertCell(1).textContent = email;
  newRow.insertCell(2).textContent = nomor;
  newRow.insertCell(3).textContent = tanggal;

  // Reset form
  document.getElementById("registerForm").reset();

  // Notifikasi
  alert("Registrasi berhasil!");
});
